let score = 0;

let players = [];

let playerName = "";

function startGame() {

    let playersInput = document.getElementById("players").value;

    players = playersInput.split(",").map(p => p.trim()).filter(p => p !== "");

    if (players.length < 10) {

        alert("⚠️ يفضل أن يكون هناك 10 لاعبين أو أكثر لزيادة الحماس، لكن يمكنك اللعب الآن!");

    }

    nextChallenge();

}

function nextChallenge() {

    if (players.length === 0) {

        alert("يرجى إدخال أسماء اللاعبين!");

        return;

    }

    playerName = players[Math.floor(Math.random() * players.length)];

    let challenges = [

        "ارقص رقصة عشوائية لمدة 10 ثواني 💃",

        "قل جملة معكوسة (ابدأ من آخر حرف إلى أول حرف) 🤯",

        "لازم تتكلم باللهجة الهندية لمدة دقيقة 😂",

        "اقنع شخص يسويلك خدمة بدون ما تشرح ليش 🤔",

        "قل 'أنا كائن فضائي' بصوت جدي وبدون ضحك 👽",

        "قل أبيات شعر غزلية كأنك شاعر محترف 🎤",

        "امدح نفسك لمدة 30 ثانية بدون ما تضحك 😎",

        "حاول إقناع شخص أن الأرض مربعة 🌎",

        "سوي صوت قطة غاضبة لمدة 5 ثواني 🐱",

        "تكلم مثل طفل صغير لمدة دقيقة 👶",

        "خمن عدد الأصابع اللي برفعها ✋",

        "اعمل تحدي تجمد لمدة 30 ثانية 🧊",

        "جاوب على سؤال بدون استخدام حرف الميم 🎤",

        "خذ نفس عميق واستمر بدون زفير لأطول وقت ممكن 😤",

        "استخدم كلمة 'بصراحة' في كل جملة لمدة دقيقة 🤥",

        "اختر لاعب وقله 'أنا أثق فيك' وانظر لرده 😆",

        "لازم تقول اسمك بطريقة كوميدية 🤪",

        "لازم تاخذ صورة سيلفي غريبة وتخليها خلفية جوالك 📸",

        "حاول عدم الرمش لمدة 20 ثانية 😳",

        "جاوب على أي سؤال يجيك بكلمة واحدة فقط 🗿",

        "سوي تحدي الإغماء المزيف وخليهم يصدقوا 🤯",

        "اقرأ جملة بشكل درامي كأنك في فيلم 🎭",

        "تكلم مثل شخصية كرتونية تحبها 🐭",

        "قل 'أنا عبقري' كلما أحد كلمك لمدة دقيقة 🧠",

        "أرسم وجه أحد اللاعبين بدون ما ترفع القلم ✏️",

        "حاول إقناع شخص أنه نسي حاجة مهمة 😆",

        "حاول تمثل أنك رجل آلي لمدة 30 ثانية 🤖",

        "أشرح شيء عادي كأنه سر خطير جدًا 🔥",

        "سوي حركة يوغا غريبة أمام الجميع 🧘",

        "اشرب كوب ماء بدون استخدام يديك 🥤",

        "لازم ترد على كل شيء بـ 'أنا مو متأكد' لمدة دقيقة 🤨",

        "سوي تصرف غريب بدون تفسير ثم ارجع عادي 🧐",

        "حاول تخمين تاريخ ميلاد أحد اللاعبين 🎂",

        "قل اسمك بالمقلوب بسرعة 🔄",

        "اصرخ فجأة بدون سبب 😱",

        "كل ما أحد سألك سؤال، جاوب ببيت شعر 🎶",

        "حاول تضحك شخص بدون ما تلمسه 😆",

        "امشي بطريقة غريبة لمدة دقيقة 🕺",

        "لازم تسأل لاعب عن عمره 3 مرات متتالية 😆"

    ];

    let randomChallenge = challenges[Math.floor(Math.random() * challenges.length)];

    

    document.getElementById("playerName").innerText = playerName;

    document.getElementById("challengeText").innerText = randomChallenge;

    document.getElementById("cardBox").classList.remove("hidden");

}

function addPoints(points) {

    score += points;

    if (score >= 1000) {

        showEnding();

    } else {

        nextChallenge();

    }

}

function showEnding() {

    document.body.innerHTML = `

        <div class="ending">

            <h1>🎉 مبروووك ${playerName}! 🎉</h1>

            <button onclick="restartGame()">🔄 العب مرة ثانية 🔄</button>

        </div>

    `;

}

function restartGame() {

    location.reload();

}